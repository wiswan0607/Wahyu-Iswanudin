/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pemula;

/**
 *
 * @author apit
 */
public class Biodata {
    public static void main(String[] arg){
        long NIK = 3516040607990002L;
        String nama = "W. Iswanudin";
        String tempatlahir = "Mojokerto";
        String tanggallahir = "06/07/1999";
        String kelamin = "Laki-Laki";
        String dusun = "Dsn. Ketapanrame";
        int Rt = 01;
        int Rw = 01;
        String desa = "Ketapanrame";
        String kecamatan = "Trawas";
        String kabupaten = "Mojokerto";
        String agama = "Islam";
        String status = "Belum Kawin";
        String pekerjaan = "Pelajar/Mahasiswa";
        String kewarganegaraan = "WNI";
        long NIM = 201969040049L;
        String prodi = "Teknik Informatika";
        int semester = 1;
        int angkatan = 2019;
        System.out.println("NIK : "+NIK);
        System.out.println("Nama lengkap : "+nama);
        System.out.println("Tempat, tanggal lahir : "+tempatlahir+", "+tanggallahir);
        System.out.println("Jenis kelamin : "+kelamin);
        System.out.println("Alamat : "+dusun);
        System.out.println("RT/RW : "+Rt+"/"+Rw);
        System.out.println("Desa : "+desa);
        System.out.println("Kecamatan : "+kecamatan);
        System.out.println("Kabupaten : "+kabupaten);
        System.out.println("Agama : "+agama);
        System.out.println("Status : "+status);
        System.out.println("Pekerjaan : "+pekerjaan);
        System.out.println("Kewarganegaraan : "+kewarganegaraan);
        System.out.println("NIM : "+NIM);
        System.out.println("Prodi : "+prodi+" semester "+semester);
        System.out.println("Angkatan : "+angkatan);
    }
}
